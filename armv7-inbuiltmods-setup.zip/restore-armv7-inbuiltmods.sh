#!/usr/bin/env bash
set -Eeuo pipefail

# Run from the LeviDroid-Modder Codespace repository root.
ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [[ -z "$ROOT" || ! -f "$ROOT/app/src/main/cpp/CMakeLists.txt" ]]; then
  echo "ERROR: Run this inside the LeviDroid-Modder repository root."
  exit 2
fi
cd "$ROOT"

BRANCH="feat/armv7-inbuiltmods-native"
if git show-ref --verify --quiet "refs/heads/$BRANCH"; then
  git switch "$BRANCH"
else
  git switch -c "$BRANCH"
fi

UPSTREAM_COMMIT="aa42c6a4fa874ce2eb66f23c41086c9b4075ec8d"
UPSTREAM_REPO="https://github.com/LiteLDev/LeviLauncher-Android.git"
echo "Recovering the native inbuilt-mod source that was removed upstream..."
git fetch --no-tags "$UPSTREAM_REPO" "$UPSTREAM_COMMIT"
UPSTREAM_REF="$(git rev-parse FETCH_HEAD)"

mkdir -p app/src/main/cpp/inbuiltmods/src/{common,fps,snaplook,zoom}
for rel in \
  CMakeLists.txt \
  src/common/transition.cpp \
  src/common/transition.h \
  src/fps/fps.cpp \
  src/snaplook/snaplook.cpp \
  src/zoom/zoom.cpp; do
  git show "$UPSTREAM_REF:app/src/main/cpp/inbuiltmods/$rel" \
    > "app/src/main/cpp/inbuiltmods/$rel"
done

# Preserve the second argument passed to CameraAPI::tryGetFOV. In the supplied
# 1.26.62.01 ARMv7 libminecraftpe.so, the slot-7 implementation reads r1, so
# a one-argument detour would not safely forward the full call frame.
python3 - <<'PY'
p = "app/src/main/cpp/inbuiltmods/src/zoom/zoom.cpp"
s = open(p, encoding="utf-8").read()
s = s.replace(
    "static uint64_t (*g_CameraAPI_tryGetFOV_orig)(void *) = nullptr;",
    "static uint64_t (*g_CameraAPI_tryGetFOV_orig)(void *, void *) = nullptr;"
)
s = s.replace(
    "static uint64_t CameraAPI_tryGetFOV_hook(void *thisPtr) {",
    "static uint64_t CameraAPI_tryGetFOV_hook(void *thisPtr, void *fovContext) {"
)
s = s.replace(
    "g_lastClientZoom = g_CameraAPI_tryGetFOV_orig(thisPtr);",
    "g_lastClientZoom = g_CameraAPI_tryGetFOV_orig(thisPtr, fovContext);"
)
if "g_CameraAPI_tryGetFOV_orig(thisPtr, fovContext)" not in s:
    raise SystemExit("Could not apply the ARMv7 CameraAPI argument-forwarding fix")
open(p, "w", encoding="utf-8").write(s)
PY

# Gyro's recovered signature contains AArch64 instruction bytes. Never scan
# an ARMv7 libminecraftpe.so with it. Export all JNI methods but report the
# feature unavailable, rather than risking a hook into an unrelated function.
cat > app/src/main/cpp/inbuiltmods/src/gyro.cpp <<'CPP'
#include <jni.h>

extern "C" {
JNIEXPORT void JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_GyroMod_nativePreResolve(
    JNIEnv *, jclass) {}

JNIEXPORT jboolean JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_GyroMod_nativeInit(
    JNIEnv *, jclass) { return JNI_FALSE; }

JNIEXPORT void JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_GyroMod_nativeSetEnabled(
    JNIEnv *, jclass, jboolean) {}

JNIEXPORT void JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_GyroMod_nativeUpdateDelta(
    JNIEnv *, jclass, jfloat, jfloat) {}

JNIEXPORT void JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_GyroMod_nativeSetSensitivityX(
    JNIEnv *, jclass, jfloat) {}

JNIEXPORT void JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_GyroMod_nativeSetSensitivityY(
    JNIEnv *, jclass, jfloat) {}

JNIEXPORT void JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_GyroMod_nativeSetInvertX(
    JNIEnv *, jclass, jboolean) {}

JNIEXPORT void JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_GyroMod_nativeSetInvertY(
    JNIEnv *, jclass, jboolean) {}

JNIEXPORT void JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_GyroMod_nativeSetDeadzone(
    JNIEnv *, jclass, jfloat) {}

JNIEXPORT jboolean JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_GyroMod_nativeIsInitialized(
    JNIEnv *, jclass) { return JNI_FALSE; }

JNIEXPORT jboolean JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_GyroMod_nativeIsEnabled(
    JNIEnv *, jclass) { return JNI_FALSE; }
}
CPP

# These features were added to the current Java wrappers after the recovered
# native source was removed. Provide safe exports so they cannot crash due to
# unresolved JNI symbols; the feature stays disabled until its real native
# implementation is ported.
cat > app/src/main/cpp/inbuiltmods/src/unavailable.cpp <<'CPP'
#include <jni.h>

extern "C" {
JNIEXPORT jboolean JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_AutoSprintMod_nativeInit(
    JNIEnv *, jclass) { return JNI_FALSE; }
JNIEXPORT void JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_AutoSprintMod_nativeSetEnabled(
    JNIEnv *, jclass, jboolean) {}
JNIEXPORT jboolean JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_AutoSprintMod_nativeIsEnabled(
    JNIEnv *, jclass) { return JNI_FALSE; }

JNIEXPORT jboolean JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_HotbarSlotMod_nativeInit(
    JNIEnv *, jclass) { return JNI_FALSE; }
JNIEXPORT void JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_HotbarSlotMod_nativeSetOverlayEnabled(
    JNIEnv *, jclass, jboolean) {}
JNIEXPORT jint JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_HotbarSlotMod_nativeGameplayVisibilityState(
    JNIEnv *, jclass) { return -1; }
JNIEXPORT jboolean JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_HotbarSlotMod_nativeItemIconsAvailable(
    JNIEnv *, jclass) { return JNI_FALSE; }
JNIEXPORT void JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_HotbarSlotMod_nativeCopyItemCounts(
    JNIEnv *env, jclass, jintArray destination) {
  if (!destination || env->GetArrayLength(destination) < 9) return;
  const jint zeros[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
  env->SetIntArrayRegion(destination, 0, 9, zeros);
}
JNIEXPORT void JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_HotbarSlotMod_nativeSetEnabled(
    JNIEnv *, jclass, jboolean) {}
JNIEXPORT void JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_HotbarSlotMod_nativeSetItemIconsEnabled(
    JNIEnv *, jclass, jboolean) {}
JNIEXPORT void JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_HotbarSlotMod_nativeSetSlotState(
    JNIEnv *, jclass, jint, jfloat, jfloat, jfloat, jfloat, jfloat, jfloat,
    jfloat, jboolean, jboolean) {}
JNIEXPORT jboolean JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_HotbarSlotMod_nativeHasItem(
    JNIEnv *, jclass, jint) { return JNI_FALSE; }
JNIEXPORT jint JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_HotbarSlotMod_nativeGetItemCount(
    JNIEnv *, jclass, jint) { return 0; }
JNIEXPORT void JNICALL
Java_org_levimc_launcher_core_mods_inbuilt_nativemod_HotbarSlotMod_nativeClearSlot(
    JNIEnv *, jclass, jint) {}
}
CPP

# Build both names because MinecraftRuntimePreparer selects inbuiltmods2660
# for Minecraft 1.26.60+. Keep ARM64 untouched; these targets are built only
# when the app's current ABI is armeabi-v7a.
cat > app/src/main/cpp/inbuiltmods/CMakeLists.txt <<'CMAKE'
cmake_minimum_required(VERSION 3.22)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

set(INBUILT_MODS_SOURCES
    src/common/transition.cpp
    src/zoom/zoom.cpp
    src/fps/fps.cpp
    src/snaplook/snaplook.cpp
    src/gyro.cpp
    src/unavailable.cpp
)

find_library(INBUILT_LOG_LIB log REQUIRED)
find_library(INBUILT_EGL_LIB EGL REQUIRED)
find_library(INBUILT_ANDROID_LIB android REQUIRED)

function(add_inbuiltmods_library target_name)
    add_library(${target_name} SHARED ${INBUILT_MODS_SOURCES})
    target_include_directories(${target_name} PRIVATE
        "${CMAKE_CURRENT_SOURCE_DIR}/src"
        "${CMAKE_CURRENT_SOURCE_DIR}/../preloader/src"
    )
    target_compile_options(${target_name} PRIVATE
        -fvisibility=hidden
        -fvisibility-inlines-hidden
    )
    target_link_libraries(${target_name} PRIVATE
        preloader
        ${INBUILT_LOG_LIB}
        ${INBUILT_EGL_LIB}
        ${INBUILT_ANDROID_LIB}
        ${CMAKE_DL_LIBS}
    )
endfunction()

add_inbuiltmods_library(inbuiltmods)
add_inbuiltmods_library(inbuiltmods2660)
CMAKE

# Add the subdirectory only for ARMv7. Existing ARM64 prebuilts remain in use.
python3 - <<'PY'
p = "app/src/main/cpp/CMakeLists.txt"
s = open(p, encoding="utf-8").read()
needle = "add_subdirectory(preloader)\n"
block = (needle + "\nif(ANDROID AND CMAKE_ANDROID_ARCH_ABI STREQUAL \"armeabi-v7a\")\n"
         "    add_subdirectory(inbuiltmods)\n"
         "endif()\n")
if "add_subdirectory(inbuiltmods)" not in s:
    if needle not in s:
        raise SystemExit("Could not find add_subdirectory(preloader) in app CMakeLists.txt")
    s = s.replace(needle, block, 1)
open(p, "w", encoding="utf-8").write(s)
PY

cat > app/src/main/cpp/inbuiltmods/ARMV7-STATUS.md <<'MD'
# ARMv7 inbuilt native library status

This restores the upstream native FPS, Snaplook and Zoom source that was removed when LeviLauncher switched to ARM64 prebuilts. The current Preloader fork's RTTI vtable resolver is used for CameraAPI and VanillaCameraAPI; both slot-7 entries were present in the supplied Minecraft 1.26.62.01 ARMv7 library.

The Zoom detour forwards both ARM32 argument registers used by the target method. The recovered Gyro signature contains AArch64 opcodes, so Gyro is intentionally disabled on ARMv7 instead of scanning an ARM binary with an AArch64 signature. AutoSprint and HotbarSlot native implementations are not present in the recovered source; safe JNI exports prevent unresolved-native crashes but these two features remain disabled.

This is a source/build recovery, not a claim that the binary has been tested on-device. Device testing is still required, and the remaining Gyro, AutoSprint and HotbarSlot ports are separate work.
MD

# Verify the source patch before starting the NDK build.
echo
echo "=== Changed files ==="
git status --short

echo
echo "=== Build ARMv7 debug APK (also produces libinbuiltmods.so and libinbuiltmods2660.so) ==="
./gradlew :app:assembleDebug --no-daemon

mapfile -t BUILT_LIBS < <(find app/.cxx app/build -type f \( -name 'libinbuiltmods.so' -o -name 'libinbuiltmods2660.so' \) 2>/dev/null | grep 'armeabi-v7a' | sort -u)
if [[ ${#BUILT_LIBS[@]} -lt 2 ]]; then
  echo "ERROR: Gradle finished but both ARMv7 native libraries were not found."
  find app/.cxx app/build -type f \( -name 'libinbuiltmods.so' -o -name 'libinbuiltmods2660.so' \) 2>/dev/null | sort | tail -30
  exit 3
fi
for lib in "${BUILT_LIBS[@]}"; do
  echo "--- $lib"
  file "$lib"
  readelf -h "$lib" | grep -E 'Class:|Machine:'
done

# Save a convenient copy in the Codespaces workspace for download from Explorer.
mkdir -p armv7-native-output
cp "${BUILT_LIBS[@]}" armv7-native-output/
find app/build/outputs/apk -type f -name '*armeabi-v7a*.apk' -exec cp {} armv7-native-output/ \; 2>/dev/null || true

git add app/src/main/cpp/CMakeLists.txt app/src/main/cpp/inbuiltmods
git -c user.name="mynameisgoodlen" -c user.email="mynameisgoodlen@users.noreply.github.com" \
  commit -m "Build ARMv7 inbuilt native libraries"
git push -u origin "$BRANCH"

echo
echo "SUCCESS: ARMv7 inbuilt native libraries and debug APK artifacts are in armv7-native-output/."
echo "Branch pushed: $BRANCH"
echo "Review app/src/main/cpp/inbuiltmods/ARMV7-STATUS.md before installing."
